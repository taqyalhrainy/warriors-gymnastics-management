const o=(i="this action")=>window.confirm(`هل أنت متأكد أنك تريد ${i}?`)?window.confirm("لا يمكن الرجوع عن هاي العملية. هل أنت متأكد؟"):!1;export{o as c};
