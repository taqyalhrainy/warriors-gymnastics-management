const t=e=>{const r=Number(e);return Number.isNaN(r)?"0 د.أ":`${r.toFixed(2)} د.أ`};export{t as f};
